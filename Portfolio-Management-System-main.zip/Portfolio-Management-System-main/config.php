<?php 

$username="root";
$servername="localhost";
$password="";
$dbname = "Portfolio_Management";
$conn= mysqli_connect($servername,$username,$password,$dbname);


?>